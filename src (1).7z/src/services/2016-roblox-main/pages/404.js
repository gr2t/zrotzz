// pages/404.js
export default function NotFoundPage() {
  return <div className='row'>
    <div className='col-6 mx-auto'>
      <h1 className='text-center'>404 - Not Found</h1>
    </div>
  </div>
}
