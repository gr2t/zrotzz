import ForumHome from "../../components/forumHome";

const DefaultPage = props => {
  return <ForumHome />
}

export default DefaultPage;