namespace Roblox.Services.Exceptions;

public class LockNotAcquiredException : System.Exception
{
    
}