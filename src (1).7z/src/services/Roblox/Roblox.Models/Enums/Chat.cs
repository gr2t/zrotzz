namespace Roblox.Models.Chat;

public enum ConversationType
{
    OneToOneConversation = 1,
}