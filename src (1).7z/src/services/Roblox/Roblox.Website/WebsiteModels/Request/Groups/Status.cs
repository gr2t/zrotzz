namespace Roblox.Website.WebsiteModels.Groups;

public class UpdateStatusRequest
{
    public string message { get; set; }
}