using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Roblox.Website.Pages;

public class Contact : RobloxPageModel
{
    public void OnGet()
    {
        
    }
}